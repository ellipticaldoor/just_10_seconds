author - Miguel Dorta
twitter - @ellipticaldoor
more info - http://withaliasing.com/games/just_10_seconds/
